'use strict';
(() => {
  const root=document.documentElement;
  const stored=localStorage.getItem('qadir-public-theme');
  root.dataset.theme=stored==='dark'||stored==='light'?stored:(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');
  document.querySelectorAll('[data-theme-toggle]').forEach(button=>button.addEventListener('click',()=>{root.dataset.theme=root.dataset.theme==='dark'?'light':'dark';localStorage.setItem('qadir-public-theme',root.dataset.theme);}));
  const nav=document.querySelector('#public-nav');
  if(nav)fetch('/api/navigation',{credentials:'same-origin',cache:'no-store'}).then(response=>response.ok?response.json():null).then(data=>{for(const item of data?.items||[]){if([...nav.querySelectorAll('a')].some(link=>link.getAttribute('href')===item.href))continue;const link=document.createElement('a');link.href=item.href;link.textContent=item.label_ar;nav.append(link);}}).catch(()=>{});
  fetch('/api/site/settings',{credentials:'same-origin',cache:'no-store'}).then(response=>response.ok?response.json():null).then(settings=>{if(settings?.site_name)document.querySelectorAll('[data-site-name]').forEach(node=>node.textContent=settings.site_name);if(settings?.logo_url){const img=document.querySelector('[data-site-logo]');if(img)img.src=settings.logo_url;}}).catch(()=>{});
})();
