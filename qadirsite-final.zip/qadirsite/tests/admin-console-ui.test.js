'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { readFileSync } = require('node:fs');
const { join } = require('node:path');

const root = join(__dirname, '..');
const html = readFileSync(join(root,'site','admin.html'),'utf8');
const js = readFileSync(join(root,'site','admin-console.js'),'utf8');
const css = readFileSync(join(root,'site','admin-console.css'),'utf8');
const db = readFileSync(join(root,'admin-db.js'),'utf8');
const api = readFileSync(join(root,'admin-api.js'),'utf8');

test('content section has a stable ID and its permission-gated CSV/PDF controls are wired', () => {
  assert.match(html, /<section id="section-content" data-admin-section="content"/);
  for (const id of ['content-export-csv','content-import-label','content-import-file','content-print-pdf']) assert.match(html,new RegExp(`id="${id}"`));
  assert.match(js,/function setupContent\(\)[\s\S]*?\$\('#section-content \.bulk-bar'\)\.hidden=!manage/);
  assert.match(js,/\$\('#content-export-csv'\)\.addEventListener\('click',exportContentCsv\)/);
  assert.match(js,/\$\('#content-import-file'\)\.addEventListener\('change',importContentCsv\)/);
  assert.match(js,/\$\('#content-print-pdf'\)\.addEventListener\('click',\(\)=>window\.print\(\)\)/);
  assert.match(css,/@media print\{/);
});

test('CSV export remains available as a template when the content table is empty', () => {
  assert.match(js,/\[columns,\.\.\.values\]/);
  assert.match(js,/qadir-content\.csv/);
  assert.match(js,/exportContentCsv\(\)[\s\S]*?can\('content\.view'\)/);
});

test('content creation only asks for the required publishing fields', () => {
  assert.match(html, /id="content-title-ar"/);
  assert.match(html, /العنوان/);
  assert.match(html, /id="content-kind-edit"/);
  assert.match(html, /id="content-state"/);
  assert.match(html, /id="content-body-ar"/);
  assert.match(html, /id="content-publish-at"/);
  assert.match(html, /صورة الغلاف \(اختياري\)/);
  assert.match(html, /id="content-slug" type="hidden"/);
  assert.match(js, /content-slug.*content/);
});

test('messages can be filtered by read state', () => {
  assert.match(html, /id="messages-read"/);
  assert.match(js, /read:\$\('#messages-read'\)\.value/);
  assert.match(js, /\$\('#messages-read'\)\.addEventListener\('change',loadMessages\)/);
  assert.match(api, /const read=url\.searchParams\.get\('read'\)/);
  assert.match(db, /read === 'unread'/);
  assert.match(db, /read === 'read'/);
});
