'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const authClient = fs.readFileSync(path.join(root, 'site', 'auth-client.js'), 'utf8');
const adminConsole = fs.readFileSync(path.join(root, 'site', 'admin-console.js'), 'utf8');
const adminHtml = fs.readFileSync(path.join(root, 'site', 'admin.html'), 'utf8');
const adminApi = fs.readFileSync(path.join(root, 'admin-api.js'), 'utf8');
const adminDb = fs.readFileSync(path.join(root, 'admin-db.js'), 'utf8');
const migration = fs.readFileSync(path.join(root, 'migrations', '004_message_channels.sql'), 'utf8');

test('users have an inbox for administration replies', () => {
  assert.match(authClient, /data-tab=\"threads\"/);
  assert.match(authClient, /\/api\/contact\/threads/);
  assert.match(authClient, /ملاحظاتي وردود الإدارة/);
  assert.match(adminDb, /message_type = 'student'/);
});

test('administration messages have student and admin channels', () => {
  assert.match(migration, /message_type ENUM/);
  assert.match(adminApi, /\['student','admin'\]/);
  assert.match(adminApi, /\/api\/admin\/messages\/admin/);
  assert.match(adminApi, /\/api\/admin\/messages\/recipients/);
  assert.match(adminDb, /addAdminMessage/);
  assert.match(adminDb, /message_type/);
  assert.match(adminConsole, /messages-type/);
  assert.match(adminConsole, /تواصل إداري/);
});

test('admin console exposes a dedicated internal messaging section with recipient names', () => {
  assert.match(adminHtml, /data-section="internal-messages"/);
  assert.match(adminHtml, /id="internal-recipient-list"/);
  assert.match(adminHtml, /id="internal-message-recipient"/);
  assert.match(adminHtml, /id="internal-admin-names"/);
  assert.doesNotMatch(adminHtml, /id="admin-message-form"/);
  assert.match(adminConsole, /loadInternalMessages/);
  assert.match(adminConsole, /recipient-card/);
  assert.match(adminApi, /messages\.view/);
});

test('internal admin messages render as a chat inbox', () => {
  assert.match(adminHtml, /id="internal-messages-list"/);
  assert.match(adminHtml, /المحادثات الإدارية/);
  assert.match(adminConsole, /loadInternalMessageInbox/);
  assert.match(adminConsole, /chat-bubble/);
  assert.match(adminConsole, /recipient_username/);
  assert.match(adminDb, /AS recipient_username/);
});

test('internal messaging can broadcast to all active administrators', () => {
  assert.match(adminConsole, /__all__/);
  assert.match(adminConsole, /كل الإداريين/);
  assert.match(adminApi, /recipientUsername!=='__all__'/);
  assert.match(adminDb, /message\.admin\.broadcast/);
  assert.match(adminDb, /sent_count/);
  assert.match(adminDb, /is_active/);
  assert.match(adminConsole, /غير النشطين/);
});
