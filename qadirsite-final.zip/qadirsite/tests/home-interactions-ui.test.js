'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const index = fs.readFileSync(path.join(__dirname, '..', 'site', 'index.html'), 'utf8');

test('desktop navigation exposes the full menu without the removed floating AI panel', () => {
  assert.match(index, /id:"qadir-menu-button"/);
  assert.doesNotMatch(index, /id:"qadir-menu-button"[^}]{0,260}className:"md:hidden/);
  assert.match(index, /Gi\.map\(c=>a\("button"/);
  assert.doesNotMatch(index, /مساعد قادر العائم/);
  assert.doesNotMatch(index, /غيّر الإجابة/);
  assert.match(index, /الإعدادات.*ملاحظاتي/);
  assert.match(index, /window\.location\.href="\/notes\.html"/);
});

test('lesson notes can be sent to the shared administrator inbox', () => {
  assert.match(index, /sendNote=async/);
  assert.match(index, /fetch\("\/api\/contact"/);
  assert.match(index, /إرسال الملاحظة للإدارة/);
  assert.match(index, /تظهر الآن لكل الإداريين/);
});

test('published question banks refresh without a page reload', () => {
  assert.match(index, /fetch\("\/api\/content\?kind=question&limit=30"/);
  assert.match(index, /setInterval\(refreshBanks,15000\)/);
  assert.match(index, /setBankItems\(live\)/);
  assert.match(index, /bankItems\.filter/);
});
